
// template_mfcdlg.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// Ctemplate_mfcdlgApp:
// See template_mfcdlg.cpp for the implementation of this class
//

class Ctemplate_mfcdlgApp : public CWinApp
{
public:
	Ctemplate_mfcdlgApp();

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern Ctemplate_mfcdlgApp theApp;