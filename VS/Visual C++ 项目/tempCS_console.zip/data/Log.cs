﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;


namespace $safeprojectname$.data
{
    class Log
    {
        public static log4net.ILog getLog()
        {
            return log4net.LogManager.GetLogger("MyLogger");
        }
    }
}
