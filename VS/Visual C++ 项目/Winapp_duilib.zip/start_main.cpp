#include "stdafx.h"

#include "duilib_framework.h"

int APIENTRY setupApp(HINSTANCE hInstance)
/// interface :   resource path , title name , size 

{
	CPaintManagerUI::SetInstance(hInstance);
	/// define the source path , include the zip path 
	CPaintManagerUI::SetResourcePath(CPaintManagerUI::GetInstancePath() + _T("demoXML"));
	//CPaintManagerUI::SetResourceZip(_T("360SafeRes.zip"));

	HRESULT Hr = ::CoInitialize(NULL);
	if (FAILED(Hr)) return 0;
	Duilib_framework* pFrame = new Duilib_framework();
	if (pFrame == NULL) return 0;
	pFrame->Create(NULL, _T("360��ȫ��ʿ"), UI_WNDSTYLE_FRAME, 0L, 0, 0, 400, 400);
	pFrame->CenterWindow();
	::ShowWindow(*pFrame, SW_SHOW);
	CPaintManagerUI::MessageLoop();
	::CoUninitialize();

	return 0;
}




int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPSTR /*lpCmdLine*/, int nCmdShow)
{
	setupApp(hInstance);
	return 0;


}