﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;


namespace tempCS_console.data
{
    class Log
    {
        public static log4net.ILog getLog()
        {
            return log4net.LogManager.GetLogger("MyLogger");
        }
    }
}
